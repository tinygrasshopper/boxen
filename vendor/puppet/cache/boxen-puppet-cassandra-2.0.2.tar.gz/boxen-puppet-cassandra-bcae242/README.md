# Cassandra Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-cassandra.png?branch=master)](https://travis-ci.org/boxen/puppet-cassandra)

## Usage

```puppet
include cassandra
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `java`
* `stdlib`

